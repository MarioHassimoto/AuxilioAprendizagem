package br.com.aprendizagem.DAO;

import br.com.aprendizagem.domain.Avaliacoes;

public class AvaliacoesDAO extends GenericDAO<Avaliacoes> {

}
