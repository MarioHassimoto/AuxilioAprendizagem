package br.com.aprendizagem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Transient;

@SuppressWarnings("serial")
@Entity
public class Usuarios extends GenericDomain{
	
	@Column(length = 50, nullable = false)
	private String nome;
	
	@Column(length = 50, nullable = false)
	private String email;
	
	@Column(length = 32, nullable = false)
	private String senha;
	
	@Column(nullable = false)
	private Character tipoUsuario;
	
	
	public Character getTipoUsuario() {
		return tipoUsuario;
	}
	public void setTipoUsuario(Character tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	@Transient
	public String getTipoFormatado() {
		String tipoFormatado = null;

		if (tipoUsuario == 'A') {
			tipoFormatado = "Administrador";
		} else if (tipoUsuario == 'B') {
			tipoFormatado = "Aluno";
		} else if (tipoUsuario == 'P') {
			tipoFormatado = "Professor";
		}
		
		return tipoFormatado;
}

}
