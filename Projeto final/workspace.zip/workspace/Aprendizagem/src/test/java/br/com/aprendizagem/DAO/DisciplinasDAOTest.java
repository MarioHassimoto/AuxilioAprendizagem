package br.com.aprendizagem.DAO;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.aprendizagem.domain.Disciplinas;

public class DisciplinasDAOTest {
	@Test
	@Ignore
	public void Salvar() {
		
		
		
		Disciplinas disciplinas = new Disciplinas();
		disciplinas.setNomeDisciplina("Portugues");
		
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		
		disciplinasDAO.salvar(disciplinas);
		
	}
	@Test
	@Ignore
	public void listar() {
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		List<Disciplinas> resultado = disciplinasDAO.listar();
		
		for(Disciplinas disciplinas : resultado) {
			System.out.println(disciplinas.getNomeDisciplina());
		}
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		Disciplinas disciplinas = disciplinasDAO.buscar(codigo);
				
		System.out.println(disciplinas.getNomeDisciplina());
	}
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		Disciplinas disciplinas = disciplinasDAO.buscar(codigo);
		disciplinasDAO.excluir(disciplinas);
		
	}
	@Test
	public void editar() {
		Long codigo = 2L;
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		Disciplinas disciplinas = disciplinasDAO.buscar(codigo);
		disciplinas.setNomeDisciplina("Matematica");
		disciplinasDAO.editar(disciplinas);
	}
	
}
