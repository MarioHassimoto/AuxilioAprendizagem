package br.com.aprendizagem.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.aprendizagem.DAO.UsuariosDAO;
import br.com.aprendizagem.domain.Usuarios;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {
	private Usuarios usuarios;
	private List<Usuarios> usuarioList;


	public Usuarios getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}

	public List<Usuarios> getUsuarioList() {
		return usuarioList;
	}

	public void setUsuarioList(List<Usuarios> usuarioList) {
		this.usuarioList = usuarioList;
	}

	@PostConstruct
	public void listar() {
		try {
			UsuariosDAO usuariosDAO = new UsuariosDAO();
			usuarioList = usuariosDAO.listar();
							
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void novo() {
		usuarios = new Usuarios();
		
	}

	public void salvar() {
		try {
			UsuariosDAO usuariosDAO = new UsuariosDAO();
			usuariosDAO.merge(usuarios);
			
			novo();
			usuarioList = usuariosDAO.listar();
			
			Messages.addGlobalInfo("Salvo com Sucesso");
		
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Salvar");
			erro.printStackTrace();
		}
	}
	public void excluir(ActionEvent evento) {
		try {
		usuarios =  (Usuarios) evento.getComponent().getAttributes().get("usuarioSelecionado");
		
		UsuariosDAO usuariosDAO = new UsuariosDAO();
		usuariosDAO.excluir(usuarios);
		
		
		usuarioList = usuariosDAO.listar();
		
		Messages.addGlobalInfo("Excluido com Sucesso");
		
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Excluir");
			erro.printStackTrace();
		}
	}
	public void editar(ActionEvent evento) {
		usuarios =  (Usuarios) evento.getComponent().getAttributes().get("usuarioSelecionado");
		
	}
	
}
