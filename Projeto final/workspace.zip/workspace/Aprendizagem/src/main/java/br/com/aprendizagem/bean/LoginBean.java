package br.com.aprendizagem.bean;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.omnifaces.util.Faces;
import org.omnifaces.util.Messages;

import br.com.aprendizagem.DAO.UsuariosDAO;
import br.com.aprendizagem.domain.Usuarios;

@ManagedBean
@SessionScoped
public class LoginBean {
	private Usuarios usuarios;

	public Usuarios getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}
	
	@PostConstruct
	public void iniciar() {
		usuarios = new Usuarios();
	}
	
	public void autenticar() {
		try {
			UsuariosDAO usuariosDAO = new UsuariosDAO();
			
			Usuarios usuarioLogado = usuariosDAO.autenticar(usuarios.getEmail(), usuarios.getSenha());
			
			if(usuarioLogado == null) {
				Messages.addFlashGlobalError("Email ou Senha Incorretos!");
				return;
			}else {
			Faces.redirect("./pages/Menu.xhtml");
			}
		} catch (IOException e) {
			Messages.addGlobalError("Erro ao Fazer o Login");
		}
	}
}
