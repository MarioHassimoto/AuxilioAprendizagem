package br.com.aprendizagem.DAO;

import org.apache.shiro.crypto.hash.SimpleHash;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import br.com.aprendizagem.domain.Usuarios;
import br.com.aprendizagem.util.HibernateUtil;


public class UsuariosDAO extends GenericDAO<Usuarios> {
	public Usuarios autenticar(String email, String senha) {
		Session sessao = HibernateUtil.getFabricaDeSessoes().openSession();

		try {
			Criteria consulta = sessao.createCriteria(Usuarios.class);
						
			consulta.add(Restrictions.eq("email", email));

			SimpleHash hash = new SimpleHash("md5", senha);
			
			consulta.add(Restrictions.eq("senha", hash.toHex()));

			Usuarios resultado = (Usuarios) consulta.uniqueResult();

			return resultado;
		} catch (RuntimeException erro) {
			throw erro;
		} finally {
			sessao.close();
		}
	}
}