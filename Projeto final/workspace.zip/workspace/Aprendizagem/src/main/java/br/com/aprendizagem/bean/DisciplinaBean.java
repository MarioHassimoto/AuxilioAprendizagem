package br.com.aprendizagem.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.aprendizagem.DAO.DisciplinasDAO;
import br.com.aprendizagem.domain.Disciplinas;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class DisciplinaBean implements Serializable {
	private Disciplinas disciplinas;
	private List<Disciplinas> disciplinaList;


	public List<Disciplinas> getDisciplinaList() {
	return disciplinaList;
	}

	public void setDisciplinaList(List<Disciplinas> disciplinaList) {
		this.disciplinaList = disciplinaList;
	}

	public Disciplinas getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(Disciplinas disciplinas) {
		this.disciplinas = disciplinas;
	}
	
	@PostConstruct
	public void listar() {
		try {
			DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
			disciplinaList = disciplinasDAO.listar();
							
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void novo() {
		disciplinas = new Disciplinas();
		
	}

	public void salvar() {
		try {
			DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
			disciplinasDAO.merge(disciplinas);
			
			novo();
			disciplinaList = disciplinasDAO.listar();
			
			Messages.addGlobalInfo("Salvo com Sucesso");
		
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Salvar");
			erro.printStackTrace();
		}
	}
	public void excluir(ActionEvent evento) {
		try {
		disciplinas =  (Disciplinas) evento.getComponent().getAttributes().get("disciplinaSelecionado");
		
		DisciplinasDAO disciplinasDAO = new DisciplinasDAO();
		disciplinasDAO.excluir(disciplinas);
		
		disciplinaList = disciplinasDAO.listar();
		
		Messages.addGlobalInfo("Excluido com Sucesso");
		
		}catch(RuntimeException erro) {
			Messages.addGlobalError("Erro ao Excluir");
			erro.printStackTrace();
		}
	}
	public void editar(ActionEvent evento) {
			disciplinas =  (Disciplinas) evento.getComponent().getAttributes().get("disciplinaSelecionado");
		
	}
}
