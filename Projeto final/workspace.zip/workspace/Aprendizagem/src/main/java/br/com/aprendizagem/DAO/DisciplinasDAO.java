package br.com.aprendizagem.DAO;

import br.com.aprendizagem.domain.Disciplinas;

public class DisciplinasDAO extends GenericDAO<Disciplinas> {

}
