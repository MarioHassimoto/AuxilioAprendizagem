package br.com.aprendizagem.DAO;

import br.com.aprendizagem.domain.Materias;

public class MateriasDAO extends GenericDAO<Materias> {

}
