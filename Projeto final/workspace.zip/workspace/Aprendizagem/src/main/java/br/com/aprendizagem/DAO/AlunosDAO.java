package br.com.aprendizagem.DAO;

import br.com.aprendizagem.domain.Alunos;

public class AlunosDAO extends GenericDAO<Alunos> {

}
