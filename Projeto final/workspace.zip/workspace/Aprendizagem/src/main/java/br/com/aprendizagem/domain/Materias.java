package br.com.aprendizagem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@SuppressWarnings("serial")
@Entity
public class Materias extends GenericDomain {
	
	@Column(nullable = false)
	private int anoMateria;
	
	@Column(length = 30, nullable = false)
	private String nomeMateria;
	
	@Column(length = 100, nullable = false)
	private String titulo;
	
	@Column(length = 10000, nullable = false)
	private String conteudo;
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	@OneToOne
	@JoinColumn(nullable = false)
	Disciplinas disciplinas;

	public int getAnoMateria() {
		return anoMateria;
	}

	public void setAnoMateria(int anoMateria) {
		this.anoMateria = anoMateria;
	}
	
		public String getNomeMateria() {
		return nomeMateria;
	}

	public void setNomeMateria(String nomeMateria) {
		this.nomeMateria = nomeMateria;
	}

	public Disciplinas getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(Disciplinas disciplinas) {
		this.disciplinas = disciplinas;
	}

	
}
