package br.com.aprendizagem.DAO;

import org.apache.shiro.crypto.hash.SimpleHash;
import org.junit.Ignore;
import org.junit.Test;

import br.com.aprendizagem.domain.Usuarios;

public class UsuariosDAOTest {
	@Test
	@Ignore
	public void Salvar() {
		
		
		
		Usuarios usuarios = new Usuarios();
		usuarios.setNome("Administrador");
		usuarios.setEmail("admin@admin");
		
		SimpleHash hash = new SimpleHash("md5", "1234");
		usuarios.setSenha(hash.toHex());
		
		
		usuarios.setTipoUsuario('A');
		
            
		UsuariosDAO usuariosDAO = new UsuariosDAO();
		
		usuariosDAO.salvar(usuarios);
		
		System.out.println("Usuário salvo com sucesso.");
		
	}
	
	@Test
	public void autenticar(){
		String email = "admin@admin";
		String senha = "1234";
		
		UsuariosDAO usuarioDAO = new UsuariosDAO();
		Usuarios usuario = usuarioDAO.autenticar(email, senha);
		
		System.out.println("Usuário autentica: " + usuario);
}
}
