package br.com.aprendizagem.DAO;

import br.com.aprendizagem.domain.RealizarAvaliacoes;

public class RealizarAvaliacoesDAO extends GenericDAO<RealizarAvaliacoes> {

}
