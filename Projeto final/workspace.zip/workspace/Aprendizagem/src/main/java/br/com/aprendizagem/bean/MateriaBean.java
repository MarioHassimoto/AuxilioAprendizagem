package br.com.aprendizagem.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.aprendizagem.DAO.DisciplinasDAO;
import br.com.aprendizagem.DAO.MateriasDAO;
import br.com.aprendizagem.domain.Disciplinas;
import br.com.aprendizagem.domain.Materias;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class MateriaBean implements Serializable {
	private Materias materias;
	private List<Materias> materiaList;
	private List<Disciplinas> disciplinaList;

	public Materias getMaterias() {
		return materias;
	}

	public void setMaterias(Materias materias) {
		this.materias = materias;
	}

	public List<Materias> getMateriaList() {
		return materiaList;
	}

	public void setMateriaList(List<Materias> materiaList) {
		this.materiaList = materiaList;
	}

	public List<Disciplinas> getDisciplinaList() {
		return disciplinaList;
	}

	public void setDisciplinaList(List<Disciplinas> disciplinaList) {
		this.disciplinaList = disciplinaList;
	}

	@PostConstruct
	public void listar() {
		try {
			MateriasDAO materiasDAO = new MateriasDAO();
			materiaList = materiasDAO.listar();

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void novo() {
		try {
			materias = new Materias();
			DisciplinasDAO disciplinaDAO = new DisciplinasDAO();
			disciplinaList = disciplinaDAO.listar();
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void salvar() {
		try {
			MateriasDAO materiasDAO = new MateriasDAO();
			materiasDAO.merge(materias);

			novo();
			materiaList = materiasDAO.listar();

			Messages.addGlobalInfo("Salvo com Sucesso");

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Salvar");
			erro.printStackTrace();
		}
	}

	public void excluir(ActionEvent evento) {
		try {
			materias = (Materias) evento.getComponent().getAttributes().get("materiaSelecionada");

			MateriasDAO materiasDAO = new MateriasDAO();
			materiasDAO.excluir(materias);

			materiaList = materiasDAO.listar();

			Messages.addGlobalInfo("Excluido com Sucesso");

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Excluir");
			erro.printStackTrace();
		}
	}

	public void editar(ActionEvent evento) {
		materias = (Materias) evento.getComponent().getAttributes().get("materiaSelecionada");

	}

}
