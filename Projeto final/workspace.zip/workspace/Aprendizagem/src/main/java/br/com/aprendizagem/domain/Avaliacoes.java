package br.com.aprendizagem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@SuppressWarnings("serial")
@Entity
public class Avaliacoes extends GenericDomain {
	
	@Column(length = 200, nullable = false)
	private String perguntas;
	
	@Column(length = 200, nullable = false)
	private String alternativaA;
	
	@Column(length = 200, nullable = false)
	private String alternativaB;
	
	@Column(length = 200, nullable = false)
	private String alternativaC;
	
	@Column(length = 200, nullable = false)
	private String alternativaD;
	
	@Column(nullable = false)
	private Character correta;
	
	@OneToOne
	@JoinColumn(nullable = false)
	Materias materias;

	public String getPerguntas() {
		return perguntas;
	}

	public void setPerguntas(String perguntas) {
		this.perguntas = perguntas;
	}

	public String getAlternativaA() {
		return alternativaA;
	}

	public void setAlternativaA(String alternativaA) {
		this.alternativaA = alternativaA;
	}

	public String getAlternativaB() {
		return alternativaB;
	}

	public void setAlternativaB(String alternativaB) {
		this.alternativaB = alternativaB;
	}

	public String getAlternativaC() {
		return alternativaC;
	}

	public void setAlternativaC(String alternativaC) {
		this.alternativaC = alternativaC;
	}

	public String getAlternativaD() {
		return alternativaD;
	}

	public void setAlternativaD(String alternativaD) {
		this.alternativaD = alternativaD;
	}

	public Character getCorreta() {
		return correta;
	}

	public void setCorreta(Character correta) {
		this.correta = correta;
	}

	public Materias getMaterias() {
		return materias;
	}

	public void setMaterias(Materias materias) {
		this.materias = materias;
	}

	

}
