package br.com.aprendizagem.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.aprendizagem.DAO.AvaliacoesDAO;
import br.com.aprendizagem.DAO.MateriasDAO;
import br.com.aprendizagem.domain.Avaliacoes;
import br.com.aprendizagem.domain.Materias;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class AvaliacaoBean implements Serializable {
	private Avaliacoes avaliacoes;
	private List<Avaliacoes> avaliacaoList;
	private List<Materias> materiaList;

	public Avaliacoes getAvaliacoes() {
		return avaliacoes;
	}

	public void setAvaliacoes(Avaliacoes avaliacoes) {
		this.avaliacoes = avaliacoes;
	}

	public List<Avaliacoes> getAvaliacaoList() {
		return avaliacaoList;
	}

	public void setAvaliacaoList(List<Avaliacoes> avaliacaoList) {
		this.avaliacaoList = avaliacaoList;
	}

	public List<Materias> getMateriaList() {
		return materiaList;
	}

	public void setMateriaList(List<Materias> materiaList) {
		this.materiaList = materiaList;
	}

	@PostConstruct
	public void listar() {
		try {
			AvaliacoesDAO avaliacoesDAO = new AvaliacoesDAO();
			avaliacaoList = avaliacoesDAO.listar();

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void novo() {
		try {
			avaliacoes = new Avaliacoes();
			MateriasDAO materiasDAO = new MateriasDAO();
			materiaList = materiasDAO.listar();
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Listar");
			erro.printStackTrace();
		}
	}

	public void salvar() {
		try {
			AvaliacoesDAO avaliacoesDAO = new AvaliacoesDAO();
			avaliacoesDAO.merge(avaliacoes);

			novo();
			avaliacaoList = avaliacoesDAO.listar();

			Messages.addGlobalInfo("Salvo com Sucesso");

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Salvar");
			erro.printStackTrace();
		}
	}

	public void excluir(ActionEvent evento) {
		try {
			avaliacoes = (Avaliacoes) evento.getComponent().getAttributes().get("avaliacaoSelecionada");

			AvaliacoesDAO avaliacoesDAO = new AvaliacoesDAO();
			avaliacoesDAO.excluir(avaliacoes);

			avaliacaoList = avaliacoesDAO.listar();

			Messages.addGlobalInfo("Excluido com Sucesso");

		} catch (RuntimeException erro) {
			Messages.addGlobalError("Erro ao Excluir");
			erro.printStackTrace();
		}
	}

	public void editar(ActionEvent evento) {
		avaliacoes = (Avaliacoes) evento.getComponent().getAttributes().get("avaliacaoSelecionada");

	}

}
